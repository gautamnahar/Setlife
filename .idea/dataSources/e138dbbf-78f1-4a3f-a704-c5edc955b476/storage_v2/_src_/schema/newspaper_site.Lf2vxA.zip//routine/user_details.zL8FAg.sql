create
    definer = root@localhost procedure user_details(IN id int)
Begin
declare email varchar(300);
declare cur1 cursor for select email_id from user where user_id = id;
Open cur1;
Fetch cur1 into email;
select email;
close cur1;
End;

