create
    definer = root@localhost function category(orders varchar(50)) returns varchar(50)
BEGIN
	declare type varchar(50);
    IF orders = 'daily' THEN
    SET type = 'Lectiophile';
	end if;
    if orders = 'weekly' then
    SET type = 'Sunday Lover';
	end if;
    if orders = 'monthly' then
    SET type = 'Bibliophobe';
	END IF;
    return type;
END;

