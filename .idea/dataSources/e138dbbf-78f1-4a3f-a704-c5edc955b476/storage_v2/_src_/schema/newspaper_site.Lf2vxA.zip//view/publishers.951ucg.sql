create definer = root@localhost view publishers as
select `newspaper_site`.`newspaper`.`news_id`    AS `news_id`,
       `newspaper_site`.`newspaper`.`name`       AS `name`,
       `newspaper_site`.`newspaper`.`news_owner` AS `news_owner`
from `newspaper_site`.`newspaper`
where (`newspaper_site`.`newspaper`.`news_id` > 0);

