create definer = root@localhost trigger calculates
    before insert
    on newspaper
    for each row
    SET new.price_per_month=new.price_per_month+100;

