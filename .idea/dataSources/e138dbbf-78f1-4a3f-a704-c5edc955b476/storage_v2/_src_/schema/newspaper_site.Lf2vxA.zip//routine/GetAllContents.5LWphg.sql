create
    definer = root@localhost procedure GetAllContents()
BEGIN
	select * from contents;
END;

